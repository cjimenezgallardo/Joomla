<?php
/*------------------------------------------------------------------------
# "Indicadores Ecnomicos de Chile" Joomla module
# Copyright (C) 2025-2030 innovate. All Rights Reserved.
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
# Author: Carlos Jimenez-Gallardo-innovate
# Website: https://www.innovate.cl
-------------------------------------------------------------------------*/
defined('_JEXEC') or die;

// Obtener la fecha actual
$today = (new DateTime())->format('d-m-Y'); // Cambia el formato si lo deseas

if (empty($data)) {
    echo '<p>No se pudo obtener la información.</p>';
    return;
}

// Verificar si la visualización es tabla o marquee
$displayMode = $params->get('display_mode', 'table'); // 'table' o 'marquee'
$marqueeDelay = $params->get('marquee_delay', 10); // Delay predeterminado si no se configura

if ($displayMode === 'marquee') {
    echo '<marquee style="font-size: 14px; white-space: nowrap;" behavior="scroll" direction="left" scrollamount="' . htmlspecialchars($marqueeDelay) . '">';
    echo 'Fecha: ' . $today . ' | ';
}

$output = ($displayMode === 'table') 
    ? '<table class="table table-striped"><thead><tr><th>Código</th><th>Valor</th></tr></thead><tbody>' 
    : '';

foreach ($selectedIndicators as $indicator) {
    if (isset($data[$indicator])) {
        $item = $data[$indicator];
        
        // Formatear el valor según la unidad
        $formattedValue = $item['unidad_medida'] === 'Pesos' 
            ? '$' . number_format($item['valor'], 2, ',', '.')
            : ($item['codigo'] === 'libra_cobre' 
                ? 'US$' . number_format($item['valor'], 2, ',', '.') 
                : number_format($item['valor'], 2, ',', '.'));
        
        // Mostrar el código en mayúsculas, con excepción de "libra_cobre"
        $code = ($item['codigo'] === 'libra_cobre') ? 'LIBRA DE COBRE' : strtoupper($item['codigo']);

        if ($displayMode === 'marquee') {
            $output .= $code . ': ' . $formattedValue . ' | ';
        } else {
            $output .= '<tr>';
            $output .= '<td>' . $code . '</td>';
            $output .= '<td>' . $formattedValue . '</td>';
            $output .= '</tr>';
        }
    }
}

if ($displayMode === 'marquee') {
    echo rtrim($output, ' | ') . '</marquee>';
} else {
    echo '<p></p>';
	echo '<caption>Fecha: ' . $today . '</caption>';
    echo $output . '</tbody></table>';
}