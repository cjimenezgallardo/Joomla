<?php
/*------------------------------------------------------------------------
# "Indicadores Ecnomicos de Chile" Joomla module
# Copyright (C) 2025-2030 innovate. All Rights Reserved.
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
# Author: Carlos Jimenez-Gallardo-innovate
# Website: https://www.innovate.cl
-------------------------------------------------------------------------*/
defined('_JEXEC') or die;

use Joomla\CMS\Http\HttpFactory;
use Joomla\CMS\Log\Log;

class ModIndicadoresHelper
{
    public static function getData()
    {
        try {
            $http = HttpFactory::getHttp();
            $response = $http->get('https://mindicador.cl/api');
            return json_decode($response->body, true);
        } catch (Exception $e) {
            Log::add('Error fetching data from API: ' . $e->getMessage(), Log::ERROR, 'mod_indicadores');
            return [];
        }
    }
}
