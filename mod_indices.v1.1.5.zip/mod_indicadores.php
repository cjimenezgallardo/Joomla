<?php
/*------------------------------------------------------------------------
# "Indicadores Ecnomicos de Chile" Joomla module
# Copyright (C) 2025-2030 innovate. All Rights Reserved.
# License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
# Author: Carlos Jimenez-Gallardo-innovate
# Website: https://www.innovate.cl
-------------------------------------------------------------------------*/
defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$data = ModIndicadoresHelper::getData();
$selectedIndicators = $params->get('indicators', []);

require ModuleHelper::getLayoutPath('mod_indicadores', $params->get('layout', 'default'));
